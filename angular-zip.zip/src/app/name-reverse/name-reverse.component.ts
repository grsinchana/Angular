import { Component } from '@angular/core';

@Component({
  selector: 'app-name-reverse',
  templateUrl: './name-reverse.component.html',
  styleUrls: ['./name-reverse.component.css']
})
export class NameReverseComponent {
  namr:any[]=[];
name: any;

}
