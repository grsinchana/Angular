import { TestBed } from '@angular/core/testing';

import { CkeckTokenService } from './ckeck-token.service';

describe('CkeckTokenService', () => {
  let service: CkeckTokenService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CkeckTokenService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
