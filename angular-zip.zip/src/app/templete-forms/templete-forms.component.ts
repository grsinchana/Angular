import { Component } from '@angular/core';

@Component({
  selector: 'app-templete-forms',
  templateUrl: './templete-forms.component.html',
  styleUrls: ['./templete-forms.component.css']
})
export class TempleteFormsComponent {
fname: string='';
pwd: string='';

}
