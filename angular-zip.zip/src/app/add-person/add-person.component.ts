import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Person } from '../person';

@Component({
  selector: 'add-person',
  templateUrl: './add-person.component.html',
  styleUrls: ['./add-person.component.css']
})
export class AddPersonComponent {


public addPerson(pAadhar: string,pName: string,pAge: number,pIsActive: boolean) {
var person = new Person(pAadhar,pName,pAge);
person.IsActive=pIsActive;
Person.AddPerson(person);
this.status=`Person with name ${person.Name} added successfullyyy`;

}


 public handleClick(s: string) {
  this.status=`You entered the state ${s}`;

  return `You enter a  state  ${s}`;
}

  public CalculateDogYears(age:number){
    return age/7;

  }
  public greeting:string =`Welcome to Karnataka Peopleeeeeee. 
                            Add yourself to this form.`  // Using `` (char beside 1) to enter the next line .


  public state:string='Karnataka';

  public p:Person=new Person ("DD3333333333333333","Sinch",21);

  public status: string='';

 
}
