import { Pipe, PipeTransform } from '@angular/core';
import { Person } from './person';

@Pipe({
  name: 'reverse'
})
export class ReversePipe implements PipeTransform {

  transform(name: any, ...args: unknown[]): any {

    var result:any []=[];
    for (let i=name.length-1;i>=0;i--){
        result.push(name[i]);
    }
    var final = result.join('')
    return final;
  }

}
