import { Injectable } from '@angular/core';
import { AppModule } from './app.module';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
}) //same as add singleton in MVC
export class SvcLoginService {

  constructor(private http:HttpClient) { }

  public login(email:string,pwd:string){
    let url="https://reqres.in/api/login";
    let body={
      email:email,
      password:pwd
    
    };
    return this.http.post(url,body);
  }
}
