import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuiltInTypeComponent } from './built-in-type.component';

describe('BuiltInTypeComponent', () => {
  let component: BuiltInTypeComponent;
  let fixture: ComponentFixture<BuiltInTypeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BuiltInTypeComponent]
    });
    fixture = TestBed.createComponent(BuiltInTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
