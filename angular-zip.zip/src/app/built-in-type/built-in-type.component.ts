import { Component } from '@angular/core';

@Component({
  selector: 'app-built-in-type',
  templateUrl: './built-in-type.component.html',
  styleUrls: ['./built-in-type.component.css']
})
export class BuiltInTypeComponent {

}
