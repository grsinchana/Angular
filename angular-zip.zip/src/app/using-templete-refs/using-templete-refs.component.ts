import { Component } from '@angular/core';

@Component({
  selector: 'app-using-templete-refs',
  templateUrl: './using-templete-refs.component.html',
  styleUrls: ['./using-templete-refs.component.css']
})
export class UsingTempleteRefsComponent {
inputcolor(_t4: any) {
  if(_t4.value=='')
    _t4.style="background-color:yellow";
  else
  _t4.style="background-color:red";
}




dontDisturb(_t2: any) {
  _t2.style ="background-color: grey";
}
switchOff(_t2: any) {
  _t2.style ="background-color: yellow";
}
lightUp(_t2: any) {
  _t2.style ="background-color: black";
}

}
