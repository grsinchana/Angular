import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsingTempleteRefsComponent } from './using-templete-refs.component';

describe('UsingTempleteRefsComponent', () => {
  let component: UsingTempleteRefsComponent;
  let fixture: ComponentFixture<UsingTempleteRefsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UsingTempleteRefsComponent]
    });
    fixture = TestBed.createComponent(UsingTempleteRefsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
