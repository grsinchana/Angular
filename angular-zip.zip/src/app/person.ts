export class Person {
    constructor(pAadhar:string='',pName:string="" ,pAge:number=18){
        this.Aadhar=pAadhar;
        this.Name=pName;
        this.age=pAge;
    }

    public Aadhar :string = " ";                       // silimar to C# string   // USE "" OR ''
    public Name:string = '';                           
    public age:number = 0;                             //- C# int,int16, int32 ,long ,decimal, short
    private secrets: string []=[];                     // C# Arrays{}
    public IsActive:boolean=true;                      // C#  boolean type
    protected hobbies:any={};                          ////use "ANY"  keyword or "UNKNOWN"  // C# object type
    protected awardsRevieved:any[]=[];                 // C#  Array type


    public static People:Person[]=[];

    public static GetPeople():Person[]{

        if(Person.People.length == 0){
        Person.People.push(new Person("AA12121212121212","Meera",24));
        Person.People.push(new Person("BB33333333333333","Neera",21));
        Person.People.push(new Person("CC22222222222222","Reena",20));
        }
        return Person.People;
    }

    public static AddPerson(person:Person):boolean{
        //Add him to Person.Person Array
        if(person==undefined){
            return false;
        }
        Person.People.push(person);
        return true;

    }


}






