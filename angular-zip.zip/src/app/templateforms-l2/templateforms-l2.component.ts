import { Component } from '@angular/core';

@Component({
  selector: 'app-templateforms-l2',
  templateUrl: './templateforms-l2.component.html',
  styleUrls: ['./templateforms-l2.component.css']
})
export class TemplateformsL2Component {
fname: string='';

}
