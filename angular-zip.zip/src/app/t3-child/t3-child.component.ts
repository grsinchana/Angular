import { Component } from '@angular/core';

@Component({
  selector: 'app-t3-child',
  templateUrl: './t3-child.component.html',
  styleUrls: ['./t3-child.component.css']
})
export class T3ChildComponent {

}
